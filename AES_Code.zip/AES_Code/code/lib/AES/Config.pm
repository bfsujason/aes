package AES::Config;

use strict;
use warnings;

use Config::General;

use File::Spec;
use File::Basename;

BEGIN {

    my $cfg_dir = dirname(__FILE__);
    my $cfg_fn  = File::Spec->catfile($cfg_dir, 'cfg');
    our %cfg    = Config::General->new(
                      -ConfigFile      => $cfg_fn,
                      -InterPolateVars => 1,
                  )->getall;
}

1;
