package AES::Model::SVR;

use strict;
use warnings;

use Storable qw(retrieve);
use List::MoreUtils qw(indexes pairwise);
use File::Slurp;

use AES::Utils;

sub new {
    my $class = shift;
    my $args  = shift;
    my $self  = $args;
    $self->{utils} = AES::Utils->new();
    bless $self, $class;
}

# run liblinear model
sub run {
    my ($self, $test_idx, $train, $test, $model, $predict, $feats_num) = @_;
    
    my $liblinear_train   = $AES::Config::cfg{liblinear_train};
    my $liblinear_predict = $AES::Config::cfg{liblinear_predict};

    print 'Training the model ... ';
    my $train_model_cmd = qq|$liblinear_train -s 11  $train $model|;
    print $train_model_cmd, "\n";
    system($train_model_cmd);
    print 'Done!', "\n";

    print 'Applying the model ... ';
    my $test_predict_cmd = qq|$liblinear_predict $test $model $predict|;
    print $test_predict_cmd, "\n";
    system($test_predict_cmd);
    print 'Done!', "\n";
	
    my $predict_scores = read_file($predict, array_ref => 1);
	if ( $self->{mode} eq 'select' ) {	# feature selection mode
		my $out_fn		= $AES::Config::cfg{bow_selection};
		open my $OUT, '>>', $out_fn;
    	my $orig_scores	= $self->{utils}->get_scores($test);
    	#my $cor        = $self->{utils}->get_cor($predict_scores, $orig_scores);
		my $mse    		= $self->{utils}->get_mse($predict_scores, $orig_scores);
		print $OUT join "\t", ($self->{fold}, $self->{t}, $self->{p}, $self->{fisher}, $self->{weight}, $feats_num, $mse);
		print $OUT "\n";
	} elsif ( $self->{mode} eq 'stack' )  {	# stacking mode
		my $out_fn	= $AES::Config::cfg{test_bow_stack}; 
		$out_fn     = $AES::Config::cfg{train_bow_stack} if $self->{fold};
		open my $OUT, '>>', $out_fn;
		my $i = 0;
   		foreach my $record ( @{$test_idx} ) {
        	my $id   = $record->{id};
        	my $pred = $predict_scores->[$i];
        	print $OUT join "\t", ($id, $pred);
       		 #print $OUT "\n";
        	$i++;
		}
    }	
}

# select bow feats
sub select_feats {
    my ($self, $feats_fn, $feats_out) = @_;
    my $index;
    open my $IN, '<', $feats_fn;
    open my $OUT, '>', $feats_out;
    print $OUT join "\t", ('Type', 'Term', 'Length', 'Freq', 'Cover', 'IDF', 'MI'), "\n";
    my $id = 0;
    while ( defined(my $record = <$IN> ) ) {
        next if $. == 1; # skip header 
        chomp $record;
        my @items  = split /\t/, $record;
        my $type   = $items[0];
        my $term   = $items[1];
        my $len    = $items[2];
        my $freq   = $items[3];
        my $cover  = $items[4];
        my $idf    = $items[5];
        my $mi     = $items[6];
        if ( $len <= $self->{$type}  && $mi < $self->{mi})  { 
        	$id++;
            my $j  = $type . '<>' . $term . '<>' . $len;
            $index->{$j} = $id;
			print $OUT join "\t", @items, "\n";
		}
	}
			return ($index, $id);
}

# vectorize data to svm format
sub vectorize {
    my ($self, $data, $idx, $feats, $svm) = @_;
    #my $data = retrieve($data_fn); # read data
    open my $OUT, '>', $svm;
    foreach my $record ( @{$idx} ) {
        my $file = $record->{id}; # data index
        #print 'Processing file ', $id, ' ... ';
        my $score     = $record->{score};
        my $feats_vec = $self->_get_feats_vec($data->{$file}, $feats);
        print $OUT $score, " ";
        print $OUT join " ", @{$feats_vec};
        print $OUT "\n";
        #print 'Done!', "\n";
    }
}

sub _get_feats_vec {
    my ($self, $data, $feats) = @_;
    my %cur_index;
    foreach my $k ( keys %{$data} ) {
        if ($feats->{$k}) {
            my $weight;
            $weight = (1 + $self->{utils}->_log($data->{$k},10) ) * $self->{idf}->{$k} if $self->{weight} eq 'tfidf';
			$weight = $self->{utils}->_log($data->{$k}, 10) if $self->{weight} eq 'logf';
			$weight = 1 if $self->{weight} eq 'binary';
            next if $weight == 0;
            #$index->{$vocab->{$k}} = $freq{$k};
            $cur_index{$feats->{$k}} = $weight;
        }
    }
    my @sorted_keys = sort { $a <=> $b } keys %cur_index;
    my @values = @cur_index{@sorted_keys};
    my $feat_val = \@values;
    $feat_val = $self->{utils}->normalize_list($feat_val) if $self->{norm};
    my @feats = pairwise { $a . ':' . $b } @sorted_keys, @{$feat_val};
    return \@feats;
}

1;
