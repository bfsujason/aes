package AES::Feats::BOW_Table;

use strict;
use warnings;

use AES::Utils;

sub new {
    my $class = shift;
    my $self  = {};
    $self->{utils} = AES::Utils->new();
    bless $self, $class;
}

sub bow2feats {
    my ($self, $bow, $meta, $feats_fn) = @_;
    my $feats = {};
    
    # get essay stats
    my ($doc_num, $ave_score, $bad_essay_num, $good_essay_num) = 
        $self->{utils}->get_essay_stats($meta, 'median');
    
    # get feats frequency
    foreach my $rec ( @{$meta} ) {
        my $id       = $rec->{id};
        my $score    = $rec->{score};
        my $cur_feat = $bow->{$id};
        foreach my $k ( keys %{$cur_feat} ) {
            $feats->{$k}->{freq}  += $cur_feat->{$k};  # update vocab frequency
            $feats->{$k}->{cover} += 1;                # update vocab coverage
            $score < $ave_score ? $feats->{$k}->{bad}++ : $feats->{$k}->{good}++;
        }
    }

    # generate feats table
    open my $OUT, '>', $feats_fn;
    print $OUT join "\t", ('Type', 'Term', 'Length', 'Freq', 'Cover', 'IDF', 'MI'); # print field names
    print $OUT "\n";

	foreach my $k ( keys %{$feats} ) {
		my ($type, $term, $length)  = split /<>/, $k;
        my $freq  = $feats->{$k}->{freq};
        my $cover = $feats->{$k}->{cover};
		my $idf   = $self->{utils}->get_idf($cover, $doc_num);

        # calculate mutual information
		my $good_present = $feats->{$k}->{good} || 1;
        my $good_missing = $good_essay_num - $good_present;
		my $bad_present  = $feats->{$k}->{bad} || 1;
        my $bad_missing  = $bad_essay_num - $bad_present;
		$good_missing    = $good_missing || 1;
		$bad_missing     = $bad_missing || 1;
		my $mi           = $self->{utils}->get_mi($good_present, $bad_present, $good_missing, $bad_missing);

		if ($freq > 1 && $mi > 0 ) {
			print $OUT join "\t", ($type, $term, $length, $freq, $cover, $idf, -$self->{utils}->_log($mi,2));
			print $OUT "\n";
		}
	}
}    


1;
