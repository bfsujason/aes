package AES::Feats::Lingua;

use strict;
use warnings;

use AES::Feats::Lingua::Length;
use AES::Feats::Lingua::Readability;
use AES::Feats::Lingua::LexVar;
use AES::Feats::Lingua::SynComp;
use AES::Feats::Lingua::Spelling;
use AES::Feats::Lingua::Grammar;
use AES::Feats::Lingua::Coherence;

sub new {
	my $class  = shift;
	my $thresh = shift;
	my $self  = {};
	$self->{len}      = AES::Feats::Lingua::Length->new();					# length features
	$self->{re}       = AES::Feats::Lingua::Readability->new();				# redability features
	$self->{lexvar}   = AES::Feats::Lingua::LexVar->new();					# lexical variety features
	$self->{syncomp}  = AES::Feats::Lingua::SynComp->new();					# syntactic complexity features
	$self->{spelling} = AES::Feats::Lingua::Spelling->new();				# spelling error features
 	$self->{grammar}  = AES::Feats::Lingua::Grammar->new();					# grammar error features
	$self->{coh}      = AES::Feats::Lingua::Coherence->new($thresh);		# coherence features

 	bless $self, $class;
}

# wrapper sub for Lingua::Length
sub get_len_feats {
	my $self = shift;
	return $self->{len}->get_len_feats(@_);
}

# wrapper sub for Lingua::Readability
sub get_re_feats {
	my $self = shift;
	return $self->{re}->get_re_feats(@_);
}

# wrapper sub for Lingua::LexVar
sub get_lexvar_feats {
	my $self = shift;
	return $self->{lexvar}->get_lexvar_feats(@_);
}

# wrapper sub for Lingua::SynComp
sub get_syncomp_feats {
	my $self = shift;
	return $self->{syncomp}->get_syncomp_feats(@_);
}

# wrapper sub for Lingua::Spelling
sub get_spelling_feats {
	my $self = shift;
	return $self->{spelling}->get_spelling_feats(@_);
}

# wrapper sub for Lingua::Grammar
sub get_grammar_feats {
	my $self = shift;
	return $self->{grammar}->get_grammar_feats(@_);
}

# wrapper sub for Lingua::Coherence
sub get_coherence_feats {
	my $self = shift;
	return $self->{coh}->get_coherence_feats(@_);
}

1;
