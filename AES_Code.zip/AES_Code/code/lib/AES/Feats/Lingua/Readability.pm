package AES::Feats::Lingua::Readability;

use strict;
use warnings;

use Lingua::EN::Syllable;
use AES::Utils;

sub new {
	my $class = shift;
	my $self  = {};
	$self->{utils} = AES::Utils->new();

	bless $self, $class;
}

sub get_re_feats {
	my ($self, $words, $word_num, $asl, $feats) = @_;
	my $complex_words;
    my $word_syllables;
    foreach my $word ( @{$words} ) {
        my $cur_syllable = syllable($word);
        $word_syllables += $cur_syllable;
        $complex_words ++ if $cur_syllable > 2;
    }

	# calculate readability
	$feats->{RE_AWS}      = $self->{utils}->_round_num($word_syllables / $word_num);								# average word syllables
    $feats->{RE_CWR}      = $self->{utils}->_round_num($complex_words / $word_num);									# complex words ratio
	$feats->{RE_FOG}      = $self->{utils}->_round_num(($asl + 100 * $feats->{RE_CWR}) * 0.4);						# fog readability index
    $feats->{RE_FLESCH}   = $self->{utils}->_round_num(206.835 - (1.015 * $asl) - (84.6 * $feats->{RE_AWS}));		# flesch readability index
   	$feats->{RE_KINCAID}  = $self->{utils}->_round_num((11.8 * $feats->{RE_AWS}) + (0.39 * $asl) - 15.59);			# kincaid readability index
}

1; 
