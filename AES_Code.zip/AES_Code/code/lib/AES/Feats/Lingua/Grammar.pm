package AES::Feats::Lingua::Grammar;

use strict;
use warnings;

use IO::Socket::INET;
use List::Util qw(sum);
use AES::Utils;

sub new {
	my $class = shift;
	my $self  = {};
	$self->{utils} = AES::Utils->new();

	bless $self, $class;	
}

# batch mode for checking errors
# in all sentences of a given text 
sub get_grammar_feats {
	my ($self, $sents, $tags, $words, $sent_num, $feats) = @_;
	my @errors = map { $self->_check_sent_err($sents->[$_], $tags->[$_]) } ( 0 .. $#$sents);

	# compute error ratios
	my $err_num  = sum @errors; 				# total number of errors
	my $word_num = scalar @{$words};			# number of words
    $feats->{'GRAMMAR_E/S'}  = $self->{utils}->_round_num($err_num / $sent_num);	# average number of grammar errors per sentence
	$feats->{'GRAMMAR_E/W'}  = $self->{utils}->_round_num($err_num / $word_num);	# average number of grammar errors per word
}

# check grammar errors in a sentence 
sub _check_sent_err {
	my ($self, $sent, $tag) = @_;
	my $error_num;
    if ( $tag !~ /VB/ or $sent =~ /\(|\)/ ) { # skip sentences such as 'Dear Mrs. Smith'
    	$error_num = 0;
    } else {
		$error_num = $self->_check_err($sent);
	}
	return $error_num;
}

sub _check_err {
    my ($self, $sent)   = @_;
	
	# connect link-gramar JAVA server
    my $socket = IO::Socket::INET->new(
        PeerHost => 'localhost',
        PeerPort => 9000,
        Proto    => 'tcp'
    ) or die "Cannot connect to the socket.\n";

	$sent = 'text:' . $sent; 	# put the prefix as requied by the server
    $socket->send($sent."\n");
    my $resp;
    $socket->recv($resp, 32);
    my ($err_num) = $resp =~ /Words":(\d+)/mxog;
    return $err_num;
}

1;
