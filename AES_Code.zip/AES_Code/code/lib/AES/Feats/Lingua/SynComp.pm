package AES::Feats::Lingua::SynComp;

use strict;
use warnings;

use AES::Anno::TreeCompiler;
use AES::Anno::TreeMatcher;

sub new {
	my $class = shift;
	my $self  = {};
	bless $self, $class;
	
	# initialize tree compiler and tree matcher
	$self->{compiler} = AES::Anno::TreeCompiler->new();
	$self->{matcher}  = AES::Anno::TreeMatcher->new();

	# compile tregex patterns
	$self->{patterns} = $self->_create_patterns();

	return $self;
}

sub get_syncomp_feats {
	my ($self, $parse, $feats) = @_;

	# calculate count for each tregex pattern
	my $pattern_count = $self->_get_pattern_count($parse, $self->{patterns});
	my $s 	 = $pattern_count->{s};			# number of sentences
	my $c_1  = $pattern_count->{c_1};		# number of clauses
	my $c_2  = $pattern_count->{c_2};		# number of fragment clauses
	my $dc   = $pattern_count->{dc};		# number of dependent clauses
	my $vp_1 = $pattern_count->{vp_1};		# number of verb phrases
	my $vp_2 = $pattern_count->{vp_2};		# number of verb phrases in interrogative sentences
	my $cn_1 = $pattern_count->{cn_1};		# number of complex nominals with pre- or post-modifiers
	my $cn_3 = $pattern_count->{cn_3};		# number of gerund nouns in subject position
	my $cp   = $pattern_count->{cp};		# number of coordinated phrases

	# calculate ratios
	$feats->{'SYN_C/S'}	    = $self->_division($c_1 + $c_2, $s);				# clause / sentence ratio
	$feats->{'SYN_DC/S'}    = $self->_division($dc, $s);						# dependent clause / sentence ratio
	$feats->{'SYN_VP/S'}    = $self->_division($vp_1 + $vp_2, $s);				# verb phrase / sentence ratio
	$feats->{'SYN_CN/S'}    = $self->_division($cn_1 + $cn_3, $s);				# complex noun phrase / sentence ratio
	$feats->{'SYN_CP/S'}    = $self->_division($cp, $s);						# coordinate phrase / sentence ratio

	#my $dc_c  = _division($dc, $c_1 + $c_2);			# SYN_DS/C
	#my $vp_c  = _division($vp_1 + $vp_2, $c_1 + $c_2);	# SYN_VP/C
	#my $cn_c  = _division($cn_1 + $cn_3, $c_1 + $c_2);	# SYN_CN/C
	#my $cp_c  = _division($cp, $c_1 + $c_2);			# SYN_CP/C
}

# match all the patterns against a given tree
sub _get_pattern_count {
    my ($self, $parse, $patterns) = @_;
    my %pattern_counts;
    foreach my $penn ( @{$parse} ) {
        #print $penn, "\n";
    	my $tree = $self->{compiler}->penn2tree($penn);
    	foreach my $pattern ( keys %{$patterns} ) {
            my $match = $self->{matcher}->match($tree, $patterns->{$pattern});
            $pattern_counts{$pattern} += $match;
    	}
    }
	return \%pattern_counts;
}

# compile tregex patterns 
sub _create_patterns {
    my $self = shift;
	my %patterns = (
	# sentence
	's'    	=> 'ROOT',
	# verb phrase			
    'vp_1' 	=> 'VP > S|SINV|SQ',	
	# verb phrase in interrogative sentence
    'vp_2' 	=> 'MD|VBZ|VBP|VBD > (SQ !< VP)',
    # clause
	'c_1'  	=> 'S|SINV|SQ [> ROOT <, (VP <# VB) | <# MD|VBZ|VBP|VBD | < (VP [<# MD|VBP|VBZ|VBD | < CC < (VP <# MD|VBP|VBZ|VBD)])]',
	# fragment clause
	'c_2'  	=> 'FRAG > ROOT !<< (S|SINV|SQ [> ROOT <, (VP <# VB) | <# MD|VBZ|VBP|VBD | < (VP [<# MD|VBP|VBZ|VBD | < CC < (VP <# MD|VBP|VBZ|VBD)])])',
	# dependent clause
    'dc'   	=> 'SBAR < (S|SINV|SQ [> ROOT <, (VP <# VB) | <# MD|VBZ|VBP|VBD | < (VP [<# MD|VBP|VBZ|VBD | < CC < (VP <# MD|VBP|VBZ|VBD)])])',	
	# t-unit    
	#'t_1'  	=> 'S|SBARQ|SINV|SQ > ROOT | [$-- S|SBARQ|SINV|SQ !>> SBAR|VP]',	
	# complex t-unit	
    #'t_2'   => 'S|SBARQ|SINV|SQ [> ROOT | [$-- S|SBARQ|SINV|SQ !>> SBAR|VP]] << (SBAR < (S|SINV|SQ [> ROOT <, (VP <# VB) | <# MD|VBZ|VBP|VBD | < (VP [<# MD|VBP|VBZ|VBD | < CC < (VP <# MD|VBP|VBZ|VBD)])]))',	
	# fregment t-unit	
	#'t_3'   => 'FRAG > ROOT !<< (S|SBARQ|SINV|SQ > ROOT | [$-- S|SBARQ|SINV|SQ !>> SBAR|VP])',  
	# coordinated phrase 
	'cp'    => 'ADJP|ADVP|NP|VP < CC',	
	# complex nominal with pre- or post-modifiers
    'cn_1'  => 'NP !> NP [<< JJ|POS|PP|S|VBG | << (NP $++ NP !$+ CC)]', 
	# nominal clause
    #'cn_2'  => 'SBAR [<# WHNP | <# (IN < That|that|For|for) | <, S] & [$+ VP | > VP]',
	# gerund nouns in subject position
    'cn_3'  => 'S < (VP <# VBG|TO) $+ VP',	# complex nominal
	);
    my %compiled_patterns;
    foreach my $k ( keys %patterns ) {
        $compiled_patterns{$k} = $self->{compiler}->compile_pattern($patterns{$k});
    }
    return \%compiled_patterns;
}

sub _division {
    my ($self, $x, $y) = @_;
    if ( $x == 0 || $y ==0 ) {
        return 0;
    } else {
        return sprintf("%.3f", $x / $y);
    }
}

1;
