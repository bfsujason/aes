package AES::Feats::Lingua::Length;

use strict;
use warnings;

use List::MoreUtils qw(indexes);
use List::Util qw(sum);

use AES::Utils;

sub new {
	my $class = shift;
	my $self  = {};
	$self->{utils} = AES::Utils->new();
	bless $self, $class;
}

sub get_len_feats {
	my ($self, $words, $tags, $sent_num, $feats) = @_;
    my @punct_index = indexes { $_ =~ /^(,|\.|\!|\?)$/ } @{$tags};
    my @word_len    = map { length $_ } @{$words};

	# calculate length features
    $feats->{LEN_CHAR}  	= sum @word_len; 														# number of characters
    $feats->{LEN_WORD}  	= scalar @{$words}; 													# number of words
    $feats->{LEN_PUNCT} 	= scalar @punct_index; 													# number of punctuations
	$feats->{LEN_SENT} 		= $sent_num;															# number of sentences
    $feats->{LEN_AWL}   	= $self->{utils}->_round_num($feats->{LEN_CHAR}/ $feats->{LEN_WORD}); 	# average word length
    $feats->{LEN_ASL}  		= $self->{utils}->_round_num($feats->{LEN_WORD} / $sent_num); 			# average sentence length
}

1;
