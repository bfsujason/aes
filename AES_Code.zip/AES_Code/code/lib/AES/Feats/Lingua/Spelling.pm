package AES::Feats::Lingua::Spelling;

use strict;
use warnings;

use Text::Aspell;
use AES::Utils;

sub new {
	my $class = shift;
	my $self  = {};

	# load Aspell
	my $aspell = Text::Aspell->new();
	$aspell->set_option('lang', 'en');
	$self->{aspell} = $aspell;
	
	$self->{utils}  = AES::Utils->new();	
	bless $self, $class;
}

sub get_spelling_feats {
	my ($self, $words, $sent_num, $feats) = @_;
	
	my $err_num  = $self->_check_txt_err($words);			# number of spelling errors
	my $word_num = scalar @{$words};						# number of words
	$feats->{'SPELLING_E/W'}   = $self->{utils}->_round_num($err_num / $word_num);		# average number of spelling errors per word
	$feats->{'SPELLING_E/S'}   = $self->{utils}->_round_num($err_num / $sent_num);		# average number of spelling erros per sentence
}

# checking spelling errors in a given text 
sub _check_txt_err {
	my ($self, $words)  = @_;
	my $errors = grep { $self->_check_spelling_err($_) } @{$words};
	return $errors;
}

# check word spelling errors
sub _check_spelling_err {
    my ($self, $word) = @_;
	#$word = lc $word;
    if ( $self->{aspell}->check($word) || $word =~ /\W|\d/ || $word =~ /^[A-Z]/ ) { # skip non-ascii words or proper names
        return 0;
    } else {
        return 1;
    }
}

1;
