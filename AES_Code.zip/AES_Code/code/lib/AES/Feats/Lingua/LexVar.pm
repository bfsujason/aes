package AES::Feats::Lingua::LexVar;

use strict;
use warnings;

use List::Util qw(uniq);
use Lingua::Diversity;

use AES::Utils;

sub new {
	my $class = shift;
	my $self  = {};
	$self->{utils}     = AES::Utils->new();
	my $seg_sampling   = Lingua::Diversity::SamplingScheme->new(
		'mode'           => 'segmental',
		'subsample_size' => 50,
	);
	my $rand_sampling  = Lingua::Diversity::SamplingScheme->new(
		'mode'           => 'random',
		'subsample_size' => 50,
	);
	$self->{guiraud}   = Lingua::Diversity::Variety->new(
		'transform' => 'guiraud',
	);
	$self->{herdan}    = Lingua::Diversity::Variety->new(
		'transform' => 'herdan',
	);
	$self->{seg}      = Lingua::Diversity::Variety->new(
		'transform'       => 'type_token_ratio',
		'sampling_scheme' => $seg_sampling,
	);
	$self->{rand}     = Lingua::Diversity::Variety->new(
		'transform'       => 'type_token_ratio',
		'sampling_scheme' => $rand_sampling,
	);
	bless $self, $class;
}

sub get_lexvar_feats {
	my ($self, $words, $feats) = @_;
	my $word_num = scalar @{$words};	# number of words
	my $type_num = uniq @{$words};		# number of types

	$feats->{TTR}      = $self->{utils}->_round_num($type_num / $word_num);									# type / token ratio
	$feats->{TTR_ROOT} = $self->{utils}->_round_num($self->{guiraud}->measure($words)->get_diversity());	# root ttr
	$feats->{TTR_LOG}  = $self->{utils}->_round_num($self->{herdan}->measure($words)->get_diversity());		# log ttr
	$feats->{TTR_SEG}  = $self->{utils}->_round_num($self->{seg}->measure($words)->get_diversity());		# segmental ttr
	$feats->{TTR_RAND} = $self->{utils}->_round_num($self->{rand}->measure($words)->get_diversity());		# random ttr
}

1;
