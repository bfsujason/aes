package AES::Feats::Lingua::Coherence;

use strict;
use warnings;

use BerkeleyDB;
use LWP::Curl;
use Text::Aspell;
use List::Util qw(uniq sum);

use AES::Config;
use AES::Utils;

sub new {
	my $class  = shift;
	my $thresh = shift;
	my $self  = {};
	bless $self, $class;
	my $stopword_fn = $AES::Config::cfg{stopword};
	$self->{stopword} = $self->_load_stopwords($stopword_fn);
	my $idf_fn = $AES::Config::cfg{bnc_idf};
    tie my %idf, "BerkeleyDB::Hash",
        -Filename => $idf_fn,
        -Flags    => DB_RDONLY;
    $self->{idf} = \%idf;
	$self->{lwpcurl} = LWP::Curl->new();
	my $aspell = Text::Aspell->new();
	$aspell->set_option('lang', 'en');
	$self->{aspell}  = $aspell;
	$self->{thresh}  = $thresh;
	$self->{utils}   = AES::Utils->new();
	return $self;
}

sub get_coherence_feats {
	my ($self, $texts, $feats) = @_;
	foreach my $text ( @{$texts} ) {
		my ($noun_indices, $word_num)  = $self->_get_nouns($text);
		my $coref_chains   = $self->_find_coref_chains($text->{coref}, $text);
		my $lexical_chains = $self->_find_lexical_chains($noun_indices, $text);
		my ($cur_local_links_ratio, $cur_global_links_ratio) = $self->_get_coh_feats($coref_chains, $lexical_chains, $text);
		#$sent_num += $cur_sent_num;
		#$local_links += $cur_local_links;
		#$global_links += $cur_global_links;
		$feats->{'COH_LOCAL'}  += $self->{utils}->_round_num($cur_local_links_ratio);
		$feats->{'COH_GLOBAL'} += $self->{utils}->_round_num($cur_global_links_ratio);
	} 
}

sub _get_links {
	my ($self, $coref_chains, $lexical_chains, $txt) = @_;
	my @chains = uniq (@{$coref_chains}, @{$lexical_chains});
	#my @chains = uniq @{$lexical_chains};
	my $chains_of;
	foreach my $edge ( @chains ) {
		my ($v1, $v2) = split /<=>/, $edge;
		my ($v1_sentID, $v1_wordID) = split /_/, $v1;
		my ($v2_sentID, $v2_wordID) = split /_/, $v2;	
		my $v1_word = lc $txt->{sent}->[$v1_sentID]->{token}->[$v1_wordID];
		my $v2_word = lc $txt->{sent}->[$v2_sentID]->{token}->[$v2_wordID];
		my $v1_tag  =  $txt->{sent}->[$v1_sentID]->{pos}->[$v1_wordID];
		my $v2_tag  = $txt->{sent}->[$v2_sentID]->{pos}->[$v2_wordID];
		#next if ( $v1_tag =~ /^PRP/ && $v2_tag =~ /^PRP/ );
		#my $weight  = $v1_word eq $v2_word ? 0.5 : 1;  
		#$chains_of->{$v1_sentID}->{$v2_sentID} += $weight;
		#$chains_of->{$v1_sentID}->{$v2_sentID}++;
		push @{$chains_of->{$v1_sentID}->{$v2_sentID}}, [$v1_word, $v2_word];
	}
	return $chains_of;
	
}

sub _get_coh_feats {
	my ($self, $coref_chains, $lexical_chains, $txt) = @_;
	my @chains = uniq (@{$coref_chains}, @{$lexical_chains});
	#my @chains = uniq @{$lexical_chains};
	my $chains_of;
	foreach my $edge ( @chains ) {
		my ($v1, $v2) = split /<=>/, $edge;
		my ($v1_sentID, $v1_wordID) = split /_/, $v1;
		my ($v2_sentID, $v2_wordID) = split /_/, $v2;	
		my $v1_word = lc $txt->{sent}->[$v1_sentID]->{token}->[$v1_wordID];
		my $v2_word = lc $txt->{sent}->[$v2_sentID]->{token}->[$v2_wordID];
		my $v1_tag  =  $txt->{sent}->[$v1_sentID]->{pos}->[$v1_wordID];
		my $v2_tag  = $txt->{sent}->[$v2_sentID]->{pos}->[$v2_wordID];
		#next if ( $v1_tag =~ /^PRP/ && $v2_tag =~ /^PRP/ );
		my $weight  = $v1_word eq $v2_word ? 0.5 : 1;  
		$chains_of->{$v1_sentID}->{$v2_sentID} += $weight;
		#$chains_of->{$v1_sentID}->{$v2_sentID}++;
	}
	
	my $local_links = 0;
	my $global_links = 0;
	my $sent_num = scalar @{$txt->{sent}};
	for ( my $i = 0; $i < $sent_num - 1; $i++ ) {
		for ( my $j = $i + 1; $j < $sent_num; $j++ ) {
			my $link_num = $chains_of->{$i}->{$j} || 0;
			#print $i, '<=>', $j, '<=>', $link_num, " ";
			if ( $link_num >= 2 ) {
				$global_links++;
				$local_links++ if $j == $i + 1;
			}
		}
	}
	#print "\n\n";
	return ($local_links / $sent_num, $global_links / $sent_num), "\n";
}

# find coref chains 
sub _find_coref_chains {
	my ($self, $coref, $txt) = @_;
	my @edges = split /\|\|/, $coref;
	my $coref_chains;
	my @result;
	foreach my $edge ( @edges ) {
		my ($v1, $v2) = split /<=>/, $edge;
		push @{$coref_chains->{$v2}}, $v1;
	}
	foreach my $k ( keys %{$coref_chains} ) {
		my $cluster = $coref_chains->{$k};
		#print join " ", @{$cluster}, "\n";
		my $cluster_size = scalar @{$cluster};
		for ( my $i = 0; $i < $cluster_size - 1; $i++ ) {
			for ( my $j = $i + 1; $j < $cluster_size; $j++ ) {
				my $v1 = $cluster->[$i];
				my $v2 = $cluster->[$j];
				#my ($v1_sentID, $v1_wordID) = split /_/, $v1;
				#my ($v2_sentID, $v2_wordID) = split /_/, $v2;
				#($v1, $v2) = ($v2, $v1) if $v1_sentID > $v2_sentID;
				push @result, $v1 . '<=>' . $v2;
			}
		}
	}
	#print join " ", @result, "\n\n";
	return \@result;
}

# find lexical chains
sub _find_lexical_chains {
    my ($self, $noun_indices, $txt) = @_;
	my $lexical_chains;
	my $noun_num = scalar @{$noun_indices}; 
	for ( my $i = 0; $i < $noun_num - 1; $i++ ) {
		for ( my $j = $i + 1; $j < $noun_num; $j++ ) {
			my $v1 = $noun_indices->[$i];
			my $v2 = $noun_indices->[$j];
			my ($v1_sentID, $v1_wordID) = split /_/, $v1;
			my ($v2_sentID, $v2_wordID) = split /_/, $v2;	
			my $v1_word = lc $txt->{sent}->[$v1_sentID]->{token}->[$v1_wordID];
			my $v2_word = lc $txt->{sent}->[$v2_sentID]->{token}->[$v2_wordID];  
			my $sim     = $self->_get_wd_sim($v1_word, $v2_word);
			if ( $sim > $self->{thresh} ) {
				($v1, $v2) = ($v2, $v1) if $v1_sentID > $v2_sentID;
				push @{$lexical_chains}, $v1 . '<=>' . $v2;
			}
		}
	}
	return $lexical_chains;
}

# extract nouns from annotated data
# return noun indices formatted in sentID_wordID
sub _get_nouns {
	my ($self, $txt) = @_;
	my $noun_indices;
	my $sent_id = 0;
	my $word_num = 0;
	foreach my $sent ( @{$txt->{sent}} ) {
		my $tokens = $sent->{token};
		$word_num += scalar @{$tokens};
		my $tags   = $sent->{pos};
		my @cur_noun_indices = grep { $self->_is_noun($tokens->[$_], $tags->[$_]) } ( 0 .. $#$tokens);
		@cur_noun_indices    = map { $sent_id . '_' . $_ } @cur_noun_indices;
		push @{$noun_indices}, @cur_noun_indices;
		$sent_id++;
	}
	return ($noun_indices, $word_num);
}


# check whether a given word is common noun
sub _is_noun {
    my ($self, $token, $tag) = @_;
	$token  = lc $token;
	my $idf = $self->{idf}->{$token} || 0;
	if ( $tag =~ /^(NN|NNS)$/ && $token =~ /\w+/ && ! $self->{stopword}->{$token} && $idf > 0.1  && $token !~ /[^\x00-\x7F]/ && $self->_is_in_word2vec($token) && ! $self->_is_spelling_err($token) ) {
		return 1;
	} else {
		return 0;
	}
}

# load stopwords
sub _load_stopwords {
	my $self    = shift;
	my $stop_fn = shift;
	my $stopwords;
	open my $IN, '<', $stop_fn;
	while ( defined(my $word = <$IN>) ) {
		chomp $word;
		next if $word =~ /#/;
		$stopwords->{$word}++;
	}
	return $stopwords;
}

# check wether a given word is wrong using Aspell
sub _is_spelling_err {
    my ($self, $word) = @_;
    if ( $self->{aspell}->check($word) || $word =~ /\W|\d/ || $word =~ /^[A-Z]/ ) {
        return 0;
    } else {
        return 1;
    }
}

# check whether a given word is in word2vec vocab
sub _is_in_word2vec {
	my $self = shift;
    my $word = shift;
    my $resp = $self->{lwpcurl}->get("http://127.0.0.1:5000/word2vec/model?word=$word");
    return $resp eq 'null' ? 0 : 1; 
}

# get word2vec similarity 
sub _get_wd_sim {
    my ($self, $w_1, $w_2) = @_;
    my $sim = $self->{lwpcurl}->get("http://127.0.0.1:5000/word2vec/similarity?w1=$w_1&w2=$w_2");
    return abs($sim);
}

1
