package AES::Anno::CoreNLP;

use strict;
use warnings;

our ($JAVA_ARGS, $JAR_PATH, $SHARED_JVM, $DIRECTORY);

BEGIN {
    $JAVA_ARGS  = $AES::Config::cfg{'jvm-mem'};
    $JAR_PATH   = $AES::Config::cfg{'jvm-cp'};
    $SHARED_JVM = $AES::Config::cfg{'jvm-share'};
    $DIRECTORY  = $AES::Config::cfg{'jvm-dir'}; 
}

use Inline (
    Java => <<'END_JAVA',

import java.util.*;
import java.io.StringReader;

import edu.stanford.nlp.ling.*;
import edu.stanford.nlp.pipeline.*;
import edu.stanford.nlp.util.*;
import edu.stanford.nlp.ling.CoreAnnotations.*;
import edu.stanford.nlp.trees.TreeCoreAnnotations.*;
import edu.stanford.nlp.trees.*;
import edu.stanford.nlp.coref.CorefCoreAnnotations;
import edu.stanford.nlp.coref.data.CorefChain;
import edu.stanford.nlp.coref.data.Mention;
import edu.stanford.nlp.coref.CorefCoreAnnotations.CorefChainAnnotation;
import edu.stanford.nlp.coref.data.CorefChain.CorefMention;

class CoreNLP {

	private StanfordCoreNLP pipeline;
    
	public CoreNLP () {
		Properties props = new Properties();
    	props.setProperty("annotators", "tokenize, ssplit, pos, lemma, ner, parse, coref");
		props.setProperty("ssplit.newlineIsSentenceBreak", "always");
		props.setProperty("tokenize.options", "americanize=true, latexQuotes=false, untokenizable=noneKeep");
		props.setProperty("ner.model", "edu/stanford/nlp/models/ner/english.conll.4class.distsim.crf.ser.gz");
		props.setProperty("ner.applyFineGrained", "false");
		//props.setProperty("parse.buildgraphs", "false");
        pipeline = new StanfordCoreNLP(props);
    }
	
	public String annotate (String text) {
		StringBuilder result = new StringBuilder();
		Annotation doc = new Annotation(text);
		pipeline.annotate(doc);
		List<CoreMap> sentences = doc.get(SentencesAnnotation.class);
		for ( CoreMap sentence : sentences ) {
			String str = sentence.get(TextAnnotation.class);
			//str = str.replaceAll("\n", " ");
			result.append(str).append("||");
			for ( CoreLabel token: sentence.get(TokensAnnotation.class) ) {
                String word  = token.get(TextAnnotation.class);
                String pos   = token.get(PartOfSpeechAnnotation.class);
                String ner   = token.get(NamedEntityTagAnnotation.class);
                String lemma = token.get(LemmaAnnotation.class);
				String item  = word + "<>" + lemma + "<>" + pos + "<>" + ner;
				result.append(item).append(" ");
            }
			result.append("||");
			Tree tree = sentence.get(TreeAnnotation.class);
			result.append(tree.toString()).append("|||");
		}
		result.append("|");
		Map<Integer, CorefChain> graph = doc.get(CorefChainAnnotation.class);
		if ( graph != null ) {
			for( CorefChain crc: graph.values() ) {
				List<CorefMention> crms = crc.getMentionsInTextualOrder();
				if ( crms.size() > 1 ) {
					CorefMention rep = crc.getRepresentativeMention();
					int rep_sent_id = rep.sentNum - 1;
					int rep_word_id = rep.headIndex -1 ;
					for ( CorefMention crm: crms ) {
						int crm_sent_id = crm.sentNum - 1;
						int crm_word_id = crm.headIndex - 1;
						String link = crm_sent_id + "_" + crm_word_id + "<=>" + rep_sent_id + "_" + rep_word_id;
						result.append(link).append("||"); 
        			}
				}
			}
		}
		return result.toString();
	}
}

END_JAVA

    CLASSPATH       => $JAR_PATH,
    EXTRA_JAVA_ARGS => $JAVA_ARGS,
    SHARED_JVM      => $SHARED_JVM,
    DIRECTORY       => $DIRECTORY,
    PACKAGE         => "AES::Anno",
);

1;
