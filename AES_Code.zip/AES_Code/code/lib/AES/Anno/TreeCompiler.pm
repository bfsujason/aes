package AES::Anno::TreeCompiler;

use strict;
use warnings;

our ($JAVA_ARGS, $JAR_PATH, $SHARED_JVM, $DIRECTORY);

BEGIN {
    $JAVA_ARGS  = $AES::Config::cfg{'jvm-mem'};
    $JAR_PATH   = $AES::Config::cfg{'jvm-cp'};
    $SHARED_JVM = $AES::Config::cfg{'jvm-share'};
    $DIRECTORY  = $AES::Config::cfg{'jvm-dir'}; 
}

use Inline (
    Java => <<'END_JAVA',

import edu.stanford.nlp.trees.tregex.TregexPattern;
import edu.stanford.nlp.trees.*;

class TreeCompiler {

    public TreeCompiler () {

    }

    public TregexPattern compile_pattern (String pattern) {
        TregexPattern compiled_pattern = TregexPattern.compile(pattern);
        return compiled_pattern;
    }

    public Tree penn2tree (String penn) {
        Tree parse = Tree.valueOf(penn);
        parse.setSpans();
        return parse;
    }
}

END_JAVA

    CLASSPATH       => $JAR_PATH,
    EXTRA_JAVA_ARGS => $JAVA_ARGS,
    #AUTOSTUDY       => 1,
    SHARED_JVM      => $SHARED_JVM,
    DIRECTORY       => $DIRECTORY,
    PACKAGE         => "AES::Anno",
);

1;
