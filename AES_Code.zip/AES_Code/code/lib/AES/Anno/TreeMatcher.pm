package AES::Anno::TreeMatcher;

use strict;
use warnings;

our ($JAVA_ARGS, $JAR_PATH, $SHARED_JVM, $DIRECTORY);

BEGIN {
    $JAVA_ARGS  = $AES::Config::cfg{'jvm-mem'};
    $JAR_PATH   = $AES::Config::cfg{'jvm-cp'};
    $SHARED_JVM = $AES::Config::cfg{'jvm-share'};
    $DIRECTORY  = $AES::Config::cfg{'jvm-dir'}; 
}

use Inline (
    Java => <<'END_JAVA',

import java.util.List;
import java.util.ArrayList;

import edu.stanford.nlp.trees.*;
import edu.stanford.nlp.util.*;
import edu.stanford.nlp.trees.tregex.TregexPattern;
import edu.stanford.nlp.trees.tregex.TregexMatcher;
import edu.stanford.nlp.trees.CollinsHeadFinder;

class TreeMatcher {

    private TregexMatcher matcher;
    private IntPair span;
    private CollinsHeadFinder hf;

    public TreeMatcher () {
        span = new IntPair();
        hf = new CollinsHeadFinder();
    }

  public int match (Tree parse, TregexPattern pattern) {
        matcher = pattern.matcher(parse);
        int count = 0;
       
        while ( matcher.findNextMatchingNode() ) {
            count++;
        }
        
        return count;
    }

    public String match_root_node (Tree parse, TregexPattern pattern) {
        matcher = pattern.matcher(parse);
        StringBuilder match = new StringBuilder();
       
        while ( matcher.findNextMatchingNode() ) {
            Tree root_node = matcher.getMatch();
            span = root_node.getSpan();
            
            match.append(span.getSource())
                 .append("-")
                 .append(span.getTarget())
                 .append("\t");
        }
        
        return match.toString();
    }

   public String match_root_node_new (Tree parse, TregexPattern pattern) {
        matcher = pattern.matcher(parse);
        StringBuilder match = new StringBuilder();
       
        while ( matcher.findNextMatchingNode() ) {
            Tree root_node = matcher.getMatch();
            match.append(root_node.toString())
                 .append("\t");
        }
        
        return match.toString();
    }

    public String match_named_nodes (Tree parse, TregexPattern pattern) {
        matcher = pattern.matcher(parse);
        StringBuilder match = new StringBuilder();
        while ( matcher.findNextMatchingNode() ) {
            Tree match_1 = matcher.getNode("node1").headTerminal(hf);
            Tree match_2 = matcher.getNode("node2").headTerminal(hf);
            match.append(match_1.toString()).
                  append("-").
                  append(match_2.toString()).
                  append("\t");
        }

        return match.toString();
    }

    public String match_node (Tree parse, TregexPattern pattern) {
        matcher = pattern.matcher(parse);
        StringBuilder match = new StringBuilder();
        while ( matcher.findNextMatchingNode() ) {
            Tree target = matcher.getNode("target").headPreTerminal(hf);
            match.append(target.getSpan().getSource()).
                  append("\t");
        }

        return match.toString();
    }
}

END_JAVA

    CLASSPATH       => $JAR_PATH,
    EXTRA_JAVA_ARGS => $JAVA_ARGS,
    #AUTOSTUDY       => 1,
    SHARED_JVM      => $SHARED_JVM,
    DIRECTORY       => $DIRECTORY,
    PACKAGE         => "AES::Anno",
);

1;
