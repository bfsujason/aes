package AES::Data::TXT2BOW;

use strict;
use warnings;

use List::MoreUtils qw(firstidx);

our $VERSION = "0.01";

sub new {
    my $class  = shift;
    my $self   = shift;
    
    bless $self, $class;
}

# given a list of terms
# return the ngrams
# list - list
sub _get_ngrams {
    my ($self, $terms, $n) = @_;
    my $ngrams;
    
    my $terms_len     = scalar @{$terms};
    my $max_start_idx = $terms_len - $n;
    
    if ( $max_start_idx >= 0 ) {
        for my $start_idx ( 0 .. $max_start_idx ) {
            my $end_idx = $start_idx + $n - 1;
            my @ngrams = @{$terms}[$start_idx .. $end_idx];
            if ( $self->{nopunct} ) {
                my $punct = firstidx { $_ =~ /^(,|\.|\:|\"|\?|\!)$/} @ngrams;
                next if $punct != -1;
            }
            my $ngram = join ' ', @ngrams;
            $ngram = lc $ngram if $self->{lc};
            push @{$ngrams}, $ngram;
        }
    }

    return $ngrams;
}

# given a list of terms and parameters
# return the vocab hash
# list - hash
###########################################
# parameters 
# range: the max length of ngram
# type: t(token), l(lemma), p(pos)
###########################################
sub doc2bow {
    my ($self, $token, $tag) = @_;
    my $bow       = {};
    my $freq_of_t = {};
    my $freq_of_p = {};
   
    $freq_of_t = $self->_get_vocab($token, $self->{t}, 't');
    $freq_of_p = $self->_get_vocab($tag, $self->{p}, 'p');
    
    %{$bow} = (%{$freq_of_t}, %{$freq_of_p});

    return $bow; 
}

sub _get_consts {
    my ($self, $parse, $type) = @_;
    my $consts;
    foreach my $const ( @{$parse} ) {
        $const = $type . '<>' . $const . '<>' . '-1'; # add dummy length
        $consts->{$const}++;
    }
    return $consts;
}

sub _get_vocab {
    my ($self, $terms, $range, $type) = @_;
    my $vocab;
    for my $i ( 1 .. $range ) {
        my $cur_grams = $self->_get_ngrams($terms, $i);
        foreach my $k ( @{$cur_grams} ) {
            $k = $type . '<>' . $k . '<>' . $i;
            $vocab->{$k}++;
        }
    }
    return $vocab;
}

1;
