package AES::Data::AnnoReader;

use strict;
use warnings;

sub new {
	my $class = shift;
	my $self  = {};
	bless $self, $class;
}

# read annotated text
sub read_anno {
	my $self = shift;
	my $fn   = shift;
	my $data;
	open my $IN, '<', $fn;
	while ( defined(my $txt = <$IN>) ) {
		chomp $txt;
		my $cur_data;
		my ($sent_anno, $coref_anno) = split /\|\|\|\|/, $txt;	# separator is "||||"
		
		# read coref annotation
		$coref_anno = $self->_delete_trailing_sep($coref_anno);
		$cur_data->{coref} = $coref_anno;

		# read sentence annotation
		my $sents = $self->_parse_sents($sent_anno);
		$cur_data->{sent} = $sents;

		# store data in an array
		push @{$data}, $cur_data;
	}
	return $data;
}

# parse annotated sentences
sub _parse_sents {
	my $self      = shift;
	my $sent_anno = shift;
	my $arr;
	my @sents     = split /\|\|\|/, $sent_anno;	# text/coref separator is "|||"
	foreach my $sent ( @sents ) {
		my $hash;
		my ($text, $words, $parse) = split /\|\|/, $sent;	# sent separator is "||"
		$words = $self->_delete_trailing_spaces($words);
		my ($tokens, $lemmas, $tags, $ners) = $self->_parse_words($words);
		$hash->{text}   = $text;
		$hash->{token}  = $tokens;
		$hash->{lemma}  = $lemmas;
		$hash->{pos}    = $tags;
		$hash->{ner}    = $ners; 
		$hash->{parse}  = $parse;
		push @{$arr}, $hash;
	}
	return $arr;
}

# parse annotated words
sub _parse_words {
	my $self  = shift;
	my $words = shift;
	my ($tokens, $lemmas, $tags, $ners);
	my @anno  = split /\s+/, $words;
	foreach my $item ( @anno ) {
		my ($token, $lemma, $pos, $ner) = split /<>/, $item;	# word annotation separator is "<>"
		push @{$tokens}, $token;
		push @{$lemmas}, $lemma;
		push @{$tags}, $pos;
		push @{$ners}, $ner;
	}
	return ($tokens, $lemmas, $tags, $ners);
}

sub _delete_trailing_spaces {
	my $self = shift;
	my $text = shift;
	$text =~ s/^\s+//g;
	$text =~ s/\s+$//g;
	return $text;
}

sub _delete_trailing_sep {
	my $self = shift;
	my $text = shift;
	$text =~ s/\|\|$//g;
	return $text;
}

1;
