package AES::Data::FCE;

use strict;
use warnings;

use File::Basename;
use XML::LibXML;

sub new {
    my $class = shift;
	my %opts  = @_;
    my $self  = {};
	$self->{print_text} = $opts{print_text};
    bless $self, $class;
}

# convert FCE XML to text
# and return the meta info
sub xml2txt {
    my $self = shift;
    my $xml  = shift;
    my $text = shift;
    open my $FH, '>:utf8', $text if $self->{print_text};
    my $dom  = XML::LibXML->load_xml(location => $xml);
    
    # find L1, age and score
    my ($cand) = $dom->findnodes('//personnel');
    my $lang   = $cand->findvalue('language/text()') || 'NULL';
    my $age    = $cand->findvalue('age/text()') || 'NULL';
    my $score  = $cand->findvalue('../score/text()') || 'NULL';
    
    # find answers
    my @texts  = $dom->findnodes('//coded_answer');
	my $text_num = scalar @texts;
	my $word_num;
    foreach my $text ( @texts ) {
    	my @paras = $text->findnodes('p');
		foreach my $para ( @paras ) {
	    	my $p = $para->toString();
            $p =~ s/^\s+//;
            my ($raw, $p_with_id) = $self->_word2id($p);
			my $cur_wc = scalar @{$raw};
            $word_num += $cur_wc;
	     	print $FH join ' ', @{$raw}, "\n" if $self->{print_text};
		}
		print $FH "\n" if $self->{print_text};
    }
    my $file_id = basename($xml, ".xml");
    return [$file_id, $lang, $age, $text_num, $word_num, $score];
}

sub _word2id {
    my ($self, $p) = @_;

    my ($node)  = XML::LibXML->load_xml(string => $p)->findnodes('p');
    my @raw;
    my $start_id = 0;
    foreach my $text ( $node->findnodes('descendant::text()') ) {
        if ($text->parentNode->nodeName eq 'c') {
            my ($sibling) = $text->parentNode->previousSibling;
            my $i_node  = XML::LibXML::Element->new('i');
            $i_node->appendText($start_id . '-' . $start_id);
            $text->parentNode->parentNode->insertBefore($i_node, $text->parentNode) if ! $sibling;
            next;
        }

        $text->deleteData(0,1), next if $text eq ' ';

        my $raw = $text->textContent();
        $raw =~ s/^\s+//;
        $raw =~ s/\s+$//;
        $raw =~ s/\s+/ /g;

        my @words = split /\s/, $raw;
        push @raw, @words;

        my $size   = scalar @words;
        my $end_id = $start_id + $size;

        $text->setData($start_id . '-' . $end_id);
        $start_id  = $end_id;
    }

    return (\@raw, $node);
}

1;
