package AES::Utils;

use strict;
use warnings;

use Text::CSV_XS qw(csv);
use Statistics::Basic qw(mean median);
use List::Util qw(sum);
use Statistics::R;

sub new {
	my $class = shift;
	my $self  = {};
	$self->{R} = Statistics::R->new();
	bless $self, $class;
}

# get all the file names in a given directory
sub get_fns {
    my ($self, $dir) = @_;
    my @fns;
    opendir(my $DH, $dir);
    foreach my $fn ( readdir $DH ) {
        next if $fn =~ /^\./;
		push @fns, $fn;
    }
    return \@fns;
}

# flattern aoa to array
sub flatten_list {
    my ($self, $list) = @_;
    my @flatten_list = map {@$_} @{$list};
    return \@flatten_list;
}

# get train data idx for fold n
sub get_train_meta {
    my ($self, $meta_fn, $n) = @_;
    my $train_meta;
    my $aoh = csv(in => $meta_fn, headers => "auto");
    foreach my $rec ( @{$aoh} ) {
        push @{$train_meta}, $rec if $rec->{fold} != $n;
    }
    return $train_meta;
}

# get essay stats
sub get_essay_stats {
    my ($self, $idx_aoh, $type) = @_;
    my @scores;
    foreach my $record ( @{$idx_aoh} ) {
        push @scores, $record->{score};
    }
    my $doc_num        = scalar @scores;
    my $ave_score      = $type eq 'mean' ? mean(@scores) : median(@scores);
    my $bad_essay_num  = grep { $_ < $ave_score } @scores;
    my $good_essay_num = $doc_num - $bad_essay_num;
    return ($doc_num, $ave_score, $bad_essay_num, $good_essay_num);
}

# get inverted document frequency
sub get_idf {
    my ($self, $cover, $docnum) = @_;
    my $idf= $self->_log($docnum / $cover, 10);
    return $idf;
}

# get mutual information of a given contingency table
sub get_mi {
	my $self = shift;
	my ($n11, $n10, $n01, $n00) = @_;
	my $n1_ = $n11 + $n10;
	my $n_1 = $n01 + $n11;
	my $n0_ = $n00 + $n01;
	my $n_0 = $n00 + $n10;

	my $n   = $n11 + $n01 + $n10 + $n00;
	my $mi  = ($n11 / $n) * $self->_log(($n * $n11) / ($n1_ * $n_1), 2) +
			  ($n01 / $n) * $self->_log(($n * $n01) / ($n0_ * $n_1), 2) +
              ($n10 / $n) * $self->_log(($n * $n10) / ($n1_ * $n_0), 2) +
              ($n00 / $n) * $self->_log(($n * $n00) / ($n0_ * $n_0), 2);
	return $mi;
}

# read FCE IDF
sub read_idf {
    my ($self, $feats_table) = @_;
    my $idf_hash;
    open my $IN, '<', $feats_table;
    while ( defined(my $line = <$IN>) ) {
        next if $. == 1; # skip header
        chomp $line;
        my ($type, $term, $length, $freq, $cover, $idf, $fisher) = split /\t/, $line;
        my $item = join '<>', ($type, $term, $length);
        $idf_hash->{$item} = $idf;
    }
    return $idf_hash;
}

# get data idx for cross validation
sub get_cv_idx {
    my ($self, $aoh, $n) = @_;
    my $train_idx;
    my $test_idx;
    foreach my $rec ( @{$aoh} ) {
        if ( $rec->{fold} == $n ) {
            push @{$test_idx}, $rec;
        } else {
            push @{$train_idx}, $rec;
        }
   }
    return ($train_idx, $test_idx);
}

# get pearson correlation of two lists
sub get_pearson {
    my ($self, $list_1, $list_2) = @_;
    $self->{R}->set('x', $list_1);
    $self->{R}->set('y', $list_2);
    $self->{R}->run(q`cor_pearson <- cor(x, y, method="pearson")`);
    return $self->{R}->get('cor_pearson');
}

# get spearman correlation of two lists
sub get_spearman {
    my ($self, $list_1, $list_2) = @_;
    $self->{R}->set('x', $list_1);
    $self->{R}->set('y', $list_2);
    $self->{R}->run(q`cor_spearman <- cor(x, y, method="spearman")`);
    return $self->{R}->get('cor_spearman');
}

# get rmse of two lists
sub get_rmse {
    my ($self, $list_1, $list_2) = @_;
	$self->{R}->run(q`library(Metrics)`);
    $self->{R}->set('x', $list_1);
    $self->{R}->set('y', $list_2);
    $self->{R}->run(q`rmse <- rmse(x, y)`);
    return $self->{R}->get('rmse');
}

# get kappa of two lists
sub get_kappa {
    my ($self, $list_1, $list_2) = @_;
	$self->{R}->run(q`library(Metrics)`);
    $self->{R}->set('x', $list_1);
    $self->{R}->set('y', $list_2);
    $self->{R}->run(q`kappa <- ScoreQuadraticWeightedKappa(as.integer(x), y)`);
    return $self->{R}->get('kappa');
}

# get mean squared error of two lists
sub get_mse {
    my ($self, $list_1, $list_2) = @_;
	my $sum = 0;
	my $n   = scalar @{$list_1};
    for my $i ( 0 .. $n - 1 ) {
		my $diff = $list_1->[$i] - $list_2->[$i];
		$sum += $diff * $diff;
	}
	return sprintf("%.3f", $sum / $n);
}

# get normalized list
sub normalize_list {
    my ($self, $list) = @_;
    my $denom = sqrt(sum(map { $_ ** 2 } @{$list}));
    my @norm = map { $_ / $denom } @{$list};
    return \@norm;
}

sub get_scores {
    my ($self, $feats) = @_;
    my @scores;
    open my $IN, '<', $feats;
    while ( defined(my $line = <$IN>) ) {
        chomp $line;
        my @vals = split /\s+/, $line;
        push @scores, $vals[0];
    }
    return \@scores;
}

# round up float numbers to three digits
sub _round_num {
	my ($self, $num) = @_;
	return sprintf("%.3f", $num);
}

sub _log {
    my ($self, $num, $base) = @_;
    return $base ? log($num)/log($base) : log($num);
}

1;
