# clear R working environment
rm(list=ls())

# load package ggplot
library(ggplot2)

# read the bow feats table
feats <- read.csv("~/aes_0.02/feats/selection/bow", sep="\t")

# combine Token and POS columns
nrow <- nrow(feats)
feats$token <- paste(rep('t', nrow), feats$token, sep="")
feats$token <- as.factor(feats$token)

feats$pos <- paste(rep('p', nrow), feats$pos, sep="")
feats$pos <- as.factor(feats$pos)

length <- paste(feats$token, feats$pos, sep="+")
feats <- data.frame(feats, length)
feats.new <- feats[feats$length == 't1+p3' | feats$length == 't2+p3',]

# # plot the distribution of bow features
# grouped by MI and N-gram length
feats.new$mi <-as.factor(feats.new$mi)
ggplot(data=feats.new, aes(x=mi, y=mse, linetype=length, group=interaction(weight, length), shape=weight)) + geom_point() + geom_line() +  xlab(expression(-log[2]*"MI")) + ylab("MSE")

# save the plot in PNG format
ggsave("~/aes_0.02/feats/selection/bow_feats_distr.png") 
