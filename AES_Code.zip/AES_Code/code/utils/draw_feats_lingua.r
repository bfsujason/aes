# clear R working environment
rm(list=ls())

# load package ggplot
library(ggplot2)

# read lingua feats table
feat <- read.csv("~/aes_0.02/feats/selection/lingua.new", sep="\t")
colnames(feat) <- c("VAR", "MSE")

# plot the importance of linguistic features
ggplot(feat, aes(x=reorder(VAR,MSE), y=MSE)) + geom_col(width=0.5) + coord_flip() + ylab("Importance") + xlab("Variables")

# save the plot in PNG format
ggsave("~/aes_0.02/feats/selection/lingua_feats_distr.png", dpi=2000) 
