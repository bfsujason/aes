#!/usr/bin/perl

# liulei@ysu.edu.cn
# 2019.08.20

# usage: perl txt2bow.pl --data train --nopunct --lc --t 3 --p 3
# the BOW data are save in <data/bow/train> and <data/bow/test>

use strict;
use warnings;

use FindBin qw($Bin);
use lib "$Bin/../lib";

use Getopt::Long;
use File::Spec;
use Text::CSV_XS qw(csv);
use Storable qw(store);

use AES::Config;
use AES::Utils;
use AES::Data::AnnoReader;
use AES::Data::TXT2BOW;

# CMD options:
# specify train or test data: --data <train|test>
# do not include punctuations in N-gram: --nopunct 
# set N-gram to lowercase: --lc
# length of word N-gram: --t 3
# length of POS N-gram: --p 3
GetOptions( \ my %opts,
    'data=s',
    'nopunct',
    'lc',
    't=i',
    'p=i',
);

# initialize classes
my $reader    = AES::Data::AnnoReader->new;
my $extractor = AES::Data::TXT2BOW->new(\%opts);
my $utils     = AES::Utils->new();

# specify input and output locations
my $meta_fn = $AES::Config::cfg{$opts{data} . '_meta'};
my $txt_dir = $AES::Config::cfg{$opts{data} . '_anno'};
my $bow_fn  = $AES::Config::cfg{$opts{data} . '_bow'}; 

# convert txt to bow
my $meta    = csv(in => $meta_fn, headers => "auto");
my $doc_num = scalar @{$meta};
my $counter = 1;
my $bow     = {};
foreach my $record ( @{$meta} ) {
    my $id = $record->{id};
    print '[', $counter, '/', $doc_num, ']: ', "\t", 'Start converting ', $id, ' ... ';
    my $txt_fn = File::Spec->catfile($txt_dir, $id);
	my $txts   = $reader->read_anno($txt_fn);
	my ($tokens, $tags);
	foreach my $txt ( @{$txts} ) {
		foreach my $sent ( @{$txt->{sent}} ) {
			my $cur_token = $sent->{token};
			my $cur_tag   = $sent->{pos};
			push @{$tokens}, $cur_token;
			push @{$tags}, $cur_tag;
		}
	}
	$tokens = $utils->flatten_list($tokens);
	$tags   = $utils->flatten_list($tags); 
    my $doc_bow = $extractor->doc2bow($tokens, $tags);
    $bow->{$id} = $doc_bow;
    $counter++;
    print 'Done!', "\n";
}

# save bow
print 'Saving bow ... ';
store($bow, $bow_fn);
print 'Done!', "\n";

__END__
