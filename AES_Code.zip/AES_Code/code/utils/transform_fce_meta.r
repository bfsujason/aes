# clear work environment
rm(list=ls())

# load package carete
library(caret)

# read in meta data
meta_fn <- "/home/jason/aes/data/meta/train"
meta <- read.csv(meta_fn)

# add doc_num column
# meta$doc_num <- length(meta$id)

# add score_class column

# score_class by mean
meta$score_mean <- as.integer(meta$score >= mean(meta$score))

# score_class by median
meta$score_median <- as.integer(meta$score >= median(meta$score))

# add fold column

# create 10 random folds
folds <- createFolds(meta$score)

# add a new column folds to the original data
meta$fold <- 0

for ( i in 1: length(folds) ) {
    meta$fold[folds[[i]]] = i
}

# save the new meta file
new_meta_fn <- "/home/jason/aes/data/meta/train"
write.csv(meta, new_meta_fn, quote=FALSE, row.names=FALSE)

