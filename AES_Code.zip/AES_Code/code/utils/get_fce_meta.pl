#!/usr/bin/perl

# liulei@ysu.edu.cn
# 2019.08.24

# usage: perl convert_fce.pl --data [train|test]

# extract metadata from FCE
# the FCE meta are saved in <data/meta/train> and <data/meta/test>

use strict;
use warnings;

use FindBin qw($Bin);
use lib "$Bin/../lib";

use Getopt::Long;
use File::Spec;
use File::Basename;
use Text::CSV_XS qw(csv);

use AES::Config;
use AES::Data::FCE;
use AES::Utils;

# CMD option: specify train or test data
GetOptions( \ my %opts,
    'data=s',
);

# initialize classes
my $fce   = AES::Data::FCE->new(print_text => 1);
my $utils = AES::Utils->new();

# specify input and output locations
my $xml_dir   = $AES::Config::cfg{$opts{data} . '_xml'};
my $txt_dir   = $AES::Config::cfg{$opts{data} . '_txt'};
my $meta_fn   = $AES::Config::cfg{$opts{data} . '_meta'};

# convert FCE XML to FCE text
# and save the meta data in CSV format
my $fns    = $utils->get_fns($xml_dir);

my $meta   = [];
my $fields = ['id', 'lang', 'age', 'texts', 'words', 'score']; # field names for meta data
push @{$meta}, $fields;
foreach my $fn ( @{$fns} ) {
    print 'Start converting ', $fn, ' ... ';
    my $in_fp    = File::Spec->catfile($xml_dir, $fn);
    my $out_fp   = File::Spec->catfile($txt_dir, basename($fn, ".xml"));
    my $cur_meta = $fce->xml2txt($in_fp, $out_fp);
    push @{$meta}, $cur_meta;
    print 'Done!', "\n";
}

print 'Starting saving metadata to ', $meta_fn, ' ... ';
csv(in => $meta, out => $meta_fn, sep_char => ",");
print 'Done!', "\n";

__END__
