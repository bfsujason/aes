#!/usr/bin/perl

# liulei@ysu.edu.cn
# 2019.08.20

# usage: perl annotate_fce.pl --data [train|test]
# annotate FCE using StanfordCoreNLP
# the annotated texts are saved in <data/anno/train> and <data/anno/test>

use strict;
use warnings;

use FindBin qw($Bin);
use lib "$Bin/../lib";

use Getopt::Long;
use Text::CSV_XS qw(csv);
use File::Spec;

use AES::Config;
use AES::Anno::CoreNLP;

# CMD option: specify train or test data
GetOptions( \ my %opts,
    'data=s',
);

# specify input and output locations
my $meta = $AES::Config::cfg{$opts{data} . '_meta'};
#my $meta  = $AES::Config::cfg{sample_meta};
my $txt   = $AES::Config::cfg{$opts{data} . '_txt'};
my $anno  = $AES::Config::cfg{$opts{data} . '_anno'};

# annotate data with StanfordCoreNLP
my $corenlp = AES::Anno::CoreNLP->new();
my $idx     = csv(in => $meta, headers => "auto");
my $counter = 1;
foreach my $rec ( @{$idx} ) {
	my $id  = $rec->{id};
	print qq{[$counter]: Starting annotating file $id ...\n};
	my $in_fn  = File::Spec->catfile($txt, $id);
	my $out_fn = File::Spec->catfile($anno, $id);
	my $texts  = _get_texts($in_fn);
	my @annotated_texts = map { $corenlp->annotate($_) } @{$texts};
	# save annotated texts
	open my $OUT, '>', $out_fn;
	foreach my $annotated_text ( @annotated_texts ) {
		print $OUT $annotated_text, "\n";
	}
	$counter++;
}

# read text as a string
sub _get_texts {
	my $path = shift;
	my @texts;
	local $/ = "" ;
	open my $FH, '<', $path;
	while ( my $text = <$FH> ) {
		chomp $text;
		push @texts, $text;
	}
	return \@texts;
}

__END__
